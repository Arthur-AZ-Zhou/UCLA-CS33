/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_310()
{
    return 2425379025U;
}

unsigned getval_143()
{
    return 3247462553U;
}

unsigned getval_442()
{
    return 2462550344U;
}

unsigned getval_139()
{
    return 3284633928U;
}

unsigned getval_275()
{
    return 3281031248U;
}

void setval_240(unsigned *p)
{
    *p = 3284631880U;
}

unsigned getval_366()
{
    return 1094304600U;
}

unsigned addval_130(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_243(unsigned *p)
{
    *p = 3531919817U;
}

void setval_127(unsigned *p)
{
    *p = 3252717896U;
}

void setval_396(unsigned *p)
{
    *p = 3526939017U;
}

unsigned getval_159()
{
    return 3373846921U;
}

unsigned getval_251()
{
    return 2497743176U;
}

unsigned addval_261(unsigned x)
{
    return x + 3281047945U;
}

void setval_175(unsigned *p)
{
    *p = 1388564105U;
}

unsigned getval_323()
{
    return 3286272328U;
}

void setval_155(unsigned *p)
{
    *p = 2430634056U;
}

unsigned addval_138(unsigned x)
{
    return x + 3674784385U;
}

unsigned getval_351()
{
    return 3285092854U;
}

void setval_100(unsigned *p)
{
    *p = 3381972617U;
}

unsigned addval_204(unsigned x)
{
    return x + 3531133321U;
}

unsigned getval_289()
{
    return 3281044105U;
}

void setval_313(unsigned *p)
{
    *p = 3380920961U;
}

unsigned getval_497()
{
    return 2430638408U;
}

unsigned addval_322(unsigned x)
{
    return x + 3526935241U;
}

void setval_219(unsigned *p)
{
    *p = 3385118345U;
}

unsigned addval_189(unsigned x)
{
    return x + 3675836809U;
}

unsigned getval_447()
{
    return 3767093753U;
}

unsigned addval_437(unsigned x)
{
    return x + 3531132553U;
}

void setval_270(unsigned *p)
{
    *p = 3286272328U;
}

void setval_223(unsigned *p)
{
    *p = 3380924045U;
}

void setval_180(unsigned *p)
{
    *p = 3352398140U;
}

void setval_414(unsigned *p)
{
    *p = 3682910857U;
}

unsigned addval_171(unsigned x)
{
    return x + 2497743176U;
}

unsigned addval_105(unsigned x)
{
    return x + 3376991881U;
}

unsigned addval_182(unsigned x)
{
    return x + 3374894729U;
}

unsigned getval_269()
{
    return 2445445553U;
}

void setval_475(unsigned *p)
{
    *p = 3683959433U;
}

void setval_383(unsigned *p)
{
    *p = 3674784457U;
}

unsigned getval_476()
{
    return 3375944075U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
